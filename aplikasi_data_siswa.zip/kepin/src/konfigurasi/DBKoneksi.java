/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package konfigurasi;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.*;
/**
 *
 * @author HP
 */
public class DBKoneksi {
    public Connection koneksi;
    
    public Connection connect(){
        try{
    Class.forName("com.mysql.jdbc.Driver");
    System.out.println("berhasil");
}catch(ClassNotFoundException ex) {
    System.out.println("gagal");
}
    

//koneksi database
try {
 String url="jdbc:mysql://localhost:3306/datasiswa";
 koneksi = DriverManager.getConnection(url,"root","");
 System.out.println("Koneksi berhasil");
 
}catch(SQLException e){
    System.out.println("Gagal koneksi");
}
return koneksi;
    }
    
public static void main(String[]args){
    java.sql.Connection conn = new DBKoneksi().connect();
}
}
    
